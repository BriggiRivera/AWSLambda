
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.11.0'
version = '1.11.0'
full_version = '1.11.0'
git_revision = '4092a9e160cc247a4a45724579a0c829733688ca'
release = True

if not release:
    version = full_version
